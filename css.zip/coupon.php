<?php
$coupon =$_POST['coupon'];
if($coupon='faizan')
{
    
}
