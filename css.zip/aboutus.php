<?php
session_start();                

?>
<html lang="en">

    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>About us</title>

	<link rel="shortcut icon" href="img/weblogo.png"/>
        <link href="css/bootstrap.css" rel="stylesheet">
        <link href="css/style.css" rel="stylesheet">
        <script src="js/jquery.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src = "http://code.jquery.com/jquery-1.11.1.min.js"></script>
    </head>

    <body>
         <?php
        include 'includes/header.php';
        ?>
        <div class="container">
            <div col="row">
        <div class="col-md-6" style="border: 1px; border-color: grey;border-style: solid; border-radius: 20px;">
            <center>
                <img src="img/pic1.jpeg" alt="" width="50%" height="50%"/>
            </center>
            <h2>Founder:</h2>
            <h3>K.faizan ali</h3>
            <h4>emailid:<br>khajifaizanali123@gmail.com</h4>
            
        </div>
                    <div class="col-md-6" style="border: 1px; border-color: grey; border-style: solid; border-radius: 20px;">
            <center>
                <img src="img/n2.jpeg" alt="" width="50%" height="50%"/>
            </center>
                        <h2>Founder:</h2>
            <h3>C.Bharath Sai reddy</h3>
            <h4>emailid:<br>chi.bharathsai@gmail.com</h4>
            
        </div>
        </div>
<div col="row">
        <div class="col-md-6" style="border: 1px; border-color: grey;border-style: solid; border-radius: 20px;">
            <center>
                <img src="img/gj.jpeg" alt="" width="50%" height="50%"/>
            </center>
             <h2>Design head:</h2>
            <h3>Jashwanth gavvala<br></h3>
            <h4>emailid:<br><br>JaswanthGavvala878@gmail.com</h4>
            
        </div>
                    <div class="col-md-6" style="border: 1px; border-color: grey; border-style: solid; border-radius: 20px;">
            <center>
                <img src="img/pic3.jpeg" alt="" width="50%" height="50%"/>
            </center>
                         <h2>Social media and documentation head:</h2>
            <h3>mahesh rayachur</h3>
            <h4>emailid:<br>rayachurmahesh99@gmail.com</h4>
            
        </div>
        </div>
            
 <div class="row">
                 <div class="col-md-offset-3 col-md-6" style="border: 1px; border-color: grey; border-style: solid; border-radius: 20px;">
            <center>
                <img src="img/pic2.jpeg" alt="" width="50%" height="50%"/>
            </center>
                     <h2>Marketing head:</h2>
            <h3>K.guru charan</h3>
            <h4>emailid:<br>gurucharan.kc@gmail.com</h4>
            
        </div>
            </div>
        </div>
        <?php
        include 'includes/footer.php';
        ?>
    </body>
</html>
