<?php
session_start();                

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Products</title>
	<link rel="shortcut icon" href="img/weblogo.png"/>
        <link href="css/bootstrap.css" rel="stylesheet">
        <link href="css/style.css" rel="stylesheet">
        <script src="js/jquery.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src = "http://code.jquery.com/jquery-1.11.1.min.js"></script>
<script src = "script_1.js"></script>
<script src = "script.js"></script>
<script src = "script_2.js"></script>
<script src = "script_3.js"></script>
<script src = "script_4.js"></script>
<script src = "script_5.js"></script>
<script src = "script_6.js"></script>
<script src = "script_7.js"></script>
<script src = "script_8.js"></script>
<script src = "script_9.js"></script>
<script src = "script_10.js"></script>
<script src = "script_11.js"></script>


    </head>

    <body>
        <?php
        include 'includes/header.php';
        
        ?>
<div class="container">
<div class="row text-center" id="watches">
                      
                       <div class="col-md-3 col-sm-6 home-feature">
                    <a href="combo2.php" style="text-decoration:none; color:black;"><div class="thumbnail">
                        <img src="img/212.jpg" alt="">
                        <div class="caption">
                            <h3>Flower combo</h3>
                             <p>(rakhi + letter + flower)</p> 
                            <h4>dukhan's price:100</h4> 
                            <p><a href="combo2.php" role="button" class="btn btn-primary btn-block" >select your rakhi</a></p>
                        </div>
                    </div></a>
                </div>
                     

                       <div class="col-md-3 col-sm-6 home-feature">
                    <a href="combo3.php" style="text-decoration:none; color:black;"><div class="thumbnail">
                        <img src="img/215.jpg" alt="">
                        <div class="caption">
                            <h3>5-star combo</h3>
                           <p>(rakhi + letter + 5-star choco)</p> 
                            <h4>dukhan's price:120</h4> 
                            <p><a href="combo3.php" role="button" class="btn btn-primary btn-block" >select your rakhi</a></p>
                        </div>
                    </div></a>
                </div>
                       
                   <div class="col-md-3 col-sm-6 home-feature">
                    <a href="combo4.php" style="text-decoration:none; color:black;"><div class="thumbnail">
                        <img src="img/218.jpg" alt="">
                        <div class="caption">
                            <h3>Sweet combo</h3>
<p>(rakhi + letter + sweet box from shirdi sai sweet shop)</p> 
                           <h4>dukhan's price:200</h4> 
                            <p><a href="combo4.php" role="button" class="btn btn-primary btn-block" >select your rakhi</a></p>
                        </div>
                    </div></a>
                </div>
<div class="col-md-3 col-sm-6 home-feature">
                    <a href="combo5.php" style="text-decoration:none; color:black;"><div class="thumbnail">
                        <img src="img/221.jpg" alt="">
                        <div class="caption">
                            <h3>Silk combo </h3>
<p>(rakhi + letter + silk chocolate)</p> 
                            <h4>dukhan's price:250</h4> 
                            <p><a href="combo5.php" role="button" class="btn btn-primary btn-block" >select your rakhi</a></p>
                        </div>
                    </div></a>
             </div>
                    </div>
<div class="row text-center" id="watches">

</div>   
  </div>
    </body>
 <?php include("includes/footer.php"); ?>
</html>
