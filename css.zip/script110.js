$(document).ready(function(){

	$('#formsubmit110').click(function(){
		$.post("submit110.php", 
			{fname: $('#fname110').val()}, 
			function(data){
				$('#response110').html(data);
			}
		);
		
	});

});