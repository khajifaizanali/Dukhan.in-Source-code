$(document).ready(function(){

	$('#formsubmit83').click(function(){
		$.post("submit83.php", 
			{fname: $('#fname83').val()}, 
			function(data){
				$('#response83').html(data);
			}
		);
		
	});

});