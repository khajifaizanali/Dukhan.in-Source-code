<footer>
    <div class="container-fluid">
        <center>
            <p> Contact Us: 9642914399,9626222139</p>	
        </center>
    </div>
</footer>