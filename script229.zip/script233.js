$(document).ready(function(){

	$('#formsubmit233').click(function(){
		$.post("submit234.php", 
			{fname: $('#fname234').val()}, 
			function(data){
				$('#response234').html(data);
			}
		);
		
	});

});