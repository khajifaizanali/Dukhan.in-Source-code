$(document).ready(function(){

	$('#formsubmit220').click(function(){
		$.post("submit220.php", 
			{ function(data){
				$('#response220').html(data);
			}
		);
		
	});

});