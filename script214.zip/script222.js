$(document).ready(function(){

	$('#formsubmit222').click(function(){
		$.post("submit222.php", 
			{ function(data){
				$('#response222').html(data);
			}
		);
		
	});

});