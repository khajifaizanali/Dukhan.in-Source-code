$(document).ready(function(){

	$('#formsubmit218').click(function(){
		$.post("submit218.php", 
			{ function(data){
				$('#response218').html(data);
			}
		);
		
	});

});